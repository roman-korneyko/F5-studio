<footer class="content-info">
  <div class="container">
    <div class="footer-widget">
      <?php (dynamic_sidebar('sidebar-footer')); ?>
    </div>
  </div>
  <div class="content-info_copyright">
    <div class="container">
      <?php (dynamic_sidebar('sidebar-footer-copyright')); ?>
    </div>
  </div>
</footer>
