<?php

namespace App;

use Sober\Controller\Controller;

class FrontPage extends Controller
{

}
