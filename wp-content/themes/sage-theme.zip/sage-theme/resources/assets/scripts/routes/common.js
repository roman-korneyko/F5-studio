export default {
  init() {
    // JavaScript to be fired on all pages
      //mob menu
      let hamburger = $('#hamburger-icon');
      let showMenu = $('.header-nav-primary');
      hamburger.click(function() {
          hamburger.toggleClass('active');
          showMenu.toggleClass('show');
          return false;
      });
      showMenu.on("click","li", function () {
            if(showMenu.hasClass('show')) {
              showMenu.toggleClass('show');
              hamburger.toggleClass('active');
          }
      })

      //scroll
      $(".menu-item").on("click","a", function (event) {
          event.preventDefault();

          let id  = $(this).attr('href');
          if(id.length > '2') {
              let top = $(id).offset().top;
              $('body,html').animate({scrollTop: top}, 1000);
          }
      });

      //sticky header
      $(window).scroll(function() {
          let header = $("header");
          let headerTop = header.height();

          if($(this).scrollTop()>=headerTop){
              header.addClass("sticky");
          } else {
              header.removeClass("sticky");
          }
      });
  },
  finalize() {
    // JavaScript to be fired on all pages, after page specific JS is fired
  },
};
