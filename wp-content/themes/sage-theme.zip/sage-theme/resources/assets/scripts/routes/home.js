export default {
  init() {
    // JavaScript to be fired on the home page
      $('.main-slider_items').slick({
          dots: true,
          prevArrow: false,
          nextArrow: false,
      });
      $('.work-width_images').slick({
          dots: false,
          prevArrow: false,
          nextArrow: false,
          slidesToShow: 6,
          slidesToScroll: 1,
          infinite: true,
          responsive: [
              {
                  breakpoint: 1024,
                  settings: {
                      slidesToShow: 3,
                      slidesToScroll: 3,
                      infinite: true,
                      dots: true,
                  },
              },
              {
                  breakpoint: 600,
                  settings: {
                      slidesToShow: 2,
                      slidesToScroll: 2,
                  },
              },
              {
                  breakpoint: 480,
                  settings: {
                      slidesToShow: 1,
                      slidesToScroll: 1,
                      dots: true,
                  },
              },
          ],
      });
  },
  finalize() {
    // JavaScript to be fired on the home page, after the init JS
  },
};
